import os
import time
import winsound

def consolewipe():
    os.system('cls')

def print_typewriter(text):
    for char in text:
        print(char, end='', flush=True)
        play_typewriter_sound()
    print()

def play_typewriter_sound():
    winsound.PlaySound("typewriter_sd.wav", winsound.SND_FILENAME)

def play_accept_sound():
    winsound.PlaySound("accept_sd.wav", winsound.SND_FILENAME)

def save_username(username):
    with open("username.txt", "w") as file:
        file.write(username)

def load_username():
    if os.path.exists("username.txt"):
        with open("username.txt", "r") as file:
            return file.read().strip()
    else:
        return None

def save_weight(weight):
    with open("weight.txt", "w") as file:
        file.write(weight)

def load_weight():
    if os.path.exists("weight.txt"):
        with open("weight.txt", "r") as file:
            return file.read().strip()
    else:
        return None

def save_pushup(pushup):
    with open("pushup.txt", "w") as file:
        file.write(pushup)

def load_pushup():
    if os.path.exists("pushup.txt"):
        with open("pushup.txt", "r") as file:
            return file.read().strip()
    else:
        return None

def save_pullup(pullup):
    with open("pullup.txt", "w") as file:
        file.write(pullup)

def load_pullup():
    if os.path.exists("pullup.txt"):
        with open("pullup.txt", "r") as file:
            return file.read().strip()
    else:
        return None

def save_squats(squats):
    with open("squats.txt", "w") as file:
        file.write(squats)

def load_squats():
    if os.path.exists("squats.txt"):
        with open("squats.txt", "r") as file:
            return file.read().strip()
    else:
        return None

def save_calvesTT(calvesTT):
    with open("calvesTT.txt", "w") as file:
        file.write(calvesTT)

def load_calvesTT():
    if os.path.exists("calvesTT.txt"):
        with open("calvesTT.txt", "r") as file:
            return file.read().strip()
    else:
        return None

def save_Tpushups(Tpushups):
    with open("Tpushups.txt", "w") as file:
        file.write(Tpushups)

def load_Tpushups():
    if os.path.exists("Tpushups.txt"):
        with open("Tpushups.txt", "r") as file:
            return file.read().strip()
    else:
        return None

def save_dumbel(dumbel):
    with open("dumbel.txt", "w") as file:
        file.write(dumbel)

def load_dumbel():
    if os.path.exists("dumbel.txt"):
        with open("dumbel.txt", "r") as file:
            return file.read().strip()
    else:
        return None

saved_username = load_username()
if saved_username:
    print(f"Welcome back, {saved_username}!")
else:
    print("Welcome!")
    print_typewriter("What should we call you?")
    username = input()
    play_accept_sound()
    save_username(username)

    consolewipe()

    weight_stat = input("How much do you weigh?")
    while True:
        try:
            int(weight_stat)
            save_weight(weight_stat)
            play_accept_sound()
            break
        except:
            weight_stat = input("Please enter a number for your weight. Round your number.")

    consolewipe()

    pushups_stat = input("How many pushups do you do per set?")
    while True:
        try:
            int(pushups_stat)
            save_pushup(pushups_stat)
            play_accept_sound()
            break
        except:
            pushups_stat = input("Please enter a number for your pushups per set. Round your number.")
    consolewipe()

    pullup_stat = input("How many pullups do you do per set?")
    while True:
        try:
            int(pullup_stat)
            save_pullup(pullup_stat)
            play_accept_sound()
            break
        except:
            pullup_stat = input("Please enter a number for your pullups per set. Round your number.")
    consolewipe()

    squats_stat = input("How many squats do you do per set?")
    while True:
        try:
            int(squats_stat)
            save_squats(squats_stat)
            play_accept_sound()
            break
        except:
            squats_stat = input("Please enter a number for your squats per set. Round your number.")
    consolewipe()

    CalvesTT_stat = input("How many calves raises do you do per set?")
    while True:
        try:
            int(CalvesTT_stat)
            save_calvesTT(CalvesTT_stat)
            play_accept_sound()
            break
        except:
            CalvesTT_stat = input("Please enter a number for your calves raises per set. Round your number.")
    consolewipe()

    TPushups_stat = input("How many triangle pushups do you do per set?")
    while True:
        try:
            int(TPushups_stat)
            save_Tpushups(TPushups_stat)
            play_accept_sound()
            break
        except:
            TPushups_stat = input("Please enter a number for your triangle pushups per set. Round your number.")
    consolewipe()

    Bcurl_stat = input("How many pounds do you Bicep curl?")
    while True:
        try:
            int(Bcurl_stat)
            save_dumbel(Bcurl_stat)
            play_accept_sound()
            break
        except:
            Bcurl_stat = input("Please enter a number for your Bicep curls per set. Round your number.")
    consolewipe()

print("Current stats")
weight = load_weight()
if weight:
    print("Weight (lbs): " + weight)
else:
    print("Weight (lbs): No data found.")

pushups = load_pushup()
if pushups:
    print("Pushups: " + pushups)
else:
    print("Pushups: No data found.")

pullup = load_pullup()
if pullup:
    print("Pullups: " + pullup)
else:
    print("Pullups: No data found.")

squats = load_squats()
if squats:
    print("Squats: " + squats)
else:
    print("Squats: No data found.")

CalveRaises = load_calvesTT()
if CalveRaises:
    print("Calve Raises: " + CalveRaises)
else:
    print("Calve Raises: No data found.")

TrianglePushups = load_Tpushups()
if TrianglePushups:
    print("Triangle Pushups: " + TrianglePushups)
else:
    print("Triangle Pushups: No data found.")

BicepCurls = load_dumbel()
if BicepCurls:
    print("Bicep Curls (lbs): " + BicepCurls)
else:
    print("Bicep Curls (lbs): No data found.")

# Update stats
update_option = input("Update stats? Press 1 to update: ")
if update_option == "1":
    consolewipe()
    print("Update Stats")

    old_weight = load_weight()
    weight_stat = input("How much do you weigh? (Press enter to keep the current value)")
    if weight_stat:
        while True:
            try:
                int(weight_stat)
                save_weight(weight_stat)
                play_accept_sound()
                break
            except:
                weight_stat = input("Please enter a number for your weight. Round your number.")
    new_weight = load_weight()
    if old_weight and new_weight:
        print(f"Weight (lbs): {old_weight} -> {new_weight}")
    elif new_weight:
        print(f"Weight (lbs): {new_weight}")

    old_pushups = load_pushup()
    pushups_stat = input("How many pushups do you do per set? (Press enter to keep the current value)")
    if pushups_stat:
        while True:
            try:
                int(pushups_stat)
                save_pushup(pushups_stat)
                play_accept_sound()
                break
            except:
                pushups_stat = input("Please enter a number for your pushups per set. Round your number.")
    new_pushups = load_pushup()
    if old_pushups and new_pushups:
        print(f"Pushups: {old_pushups} -> {new_pushups}")
    elif new_pushups:
        print(f"Pushups: {new_pushups}")

    old_pullup = load_pullup()
    pullup_stat = input("How many pullups do you do per set? (Press enter to keep the current value)")
    if pullup_stat:
        while True:
            try:
                int(pullup_stat)
                save_pullup(pullup_stat)
                play_accept_sound()
                break
            except:
                pullup_stat = input("Please enter a number for your pullups per set. Round your number.")
    new_pullup = load_pullup()
    if old_pullup and new_pullup:
        print(f"Pullups: {old_pullup} -> {new_pullup}")
    elif new_pullup:
        print(f"Pullups: {new_pullup}")

    old_squats = load_squats()
    squats_stat = input("How many squats do you do per set? (Press enter to keep the current value)")
    if squats_stat:
        while True:
            try:
                int(squats_stat)
                save_squats(squats_stat)
                play_accept_sound()
                break
            except:
                squats_stat = input("Please enter a number for your squats per set. Round your number.")
    new_squats = load_squats()
    if old_squats and new_squats:
        print(f"Squats: {old_squats} -> {new_squats}")
    elif new_squats:
        print(f"Squats: {new_squats}")

    old_calvesTT = load_calvesTT()
    CalvesTT_stat = input("How many calves raises do you do per set? (Press enter to keep the current value)")
    if CalvesTT_stat:
        while True:
            try:
                int(CalvesTT_stat)
                save_calvesTT(CalvesTT_stat)
                play_accept_sound()
                break
            except:
                CalvesTT_stat = input("Please enter a number for your calves raises per set. Round your number.")
    new_calvesTT = load_calvesTT()
    if old_calvesTT and new_calvesTT:
        print(f"Calve Raises: {old_calvesTT} -> {new_calvesTT}")
    elif new_calvesTT:
        print(f"Calve Raises: {new_calvesTT}")

    old_Tpushups = load_Tpushups()
    TPushups_stat = input("How many triangle pushups do you do per set? (Press enter to keep the current value)")
    if TPushups_stat:
        while True:
            try:
                int(TPushups_stat)
                save_Tpushups(TPushups_stat)
                play_accept_sound()
                break
            except:
                TPushups_stat = input("Please enter a number for your triangle pushups per set. Round your number.")
    new_Tpushups = load_Tpushups()
    if old_Tpushups and new_Tpushups:
        print(f"Triangle Pushups: {old_Tpushups} -> {new_Tpushups}")
    elif new_Tpushups:
        print(f"Triangle Pushups: {new_Tpushups}")

    old_dumbel = load_dumbel()
    Bcurl_stat = input("How many pounds do you Bicep curl? (Press enter to keep the current value)")
    if Bcurl_stat:
        while True:
            try:
                int(Bcurl_stat)
                save_dumbel(Bcurl_stat)
                play_accept_sound()
                break
            except:
                Bcurl_stat = input("Please enter a number for your Bicep curls per set. Round your number.")
    new_dumbel = load_dumbel()
    if old_dumbel and new_dumbel:
        print(f"Bicep Curls (lbs): {old_dumbel} -> {new_dumbel}")
    elif new_dumbel:
        print(f"Bicep Curls (lbs): {new_dumbel}")

    consolewipe()
    print("Stats Updated")
    time.sleep(1)

print("Current stats")
weight = load_weight()
if weight:
    print("Weight (lbs): " + weight)
else:
    print("Weight (lbs): No data found.")

pushups = load_pushup()
if pushups:
    print("Pushups: " + pushups)
else:
    print("Pushups: No data found.")

pullup = load_pullup()
if pullup:
    print("Pullups: " + pullup)
else:
    print("Pullups: No data found.")

squats = load_squats()
if squats:
    print("Squats: " + squats)
else:
    print("Squats: No data found.")

CalveRaises = load_calvesTT()
if CalveRaises:
    print("Calve Raises: " + CalveRaises)
else:
    print("Calve Raises: No data found.")

TrianglePushups = load_Tpushups()
if TrianglePushups:
    print("Triangle Pushups: " + TrianglePushups)
else:
    print("Triangle Pushups: No data found.")

BicepCurls = load_dumbel()
if BicepCurls:
    print("Bicep Curls (lbs): " + BicepCurls)
else:
    print("Bicep Curls (lbs): No data found.")
